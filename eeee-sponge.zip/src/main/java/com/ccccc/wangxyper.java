package com.ccccc;

import com.ccccc.plug.tps.TPSGet;
import com.google.inject.Inject;
import org.slf4j.Logger;
import org.spongepowered.api.Sponge;
import org.spongepowered.api.command.CommandCallable;
import org.spongepowered.api.event.game.state.GameStartedServerEvent;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.plugin.Plugin;
import org.spongepowered.api.plugin.PluginContainer;
import com.ccccc.plug.tps.gettps;
import javax.annotation.Nullable;

import static com.ccccc.plug.tabbar.register.tabbar;
import static com.ccccc.plug.tps.gettps.*;
@Plugin(
        id = "eeee-sponge",
        name = "Eeee"
)
public class wangxyper {
Object plugin = new gettps() {
    @Override
    public String getId() {
        return null;
    }
};


    @Listener
    public void onServerStart(GameStartedServerEvent event) {
        Sponge.getCommandManager().register(plugin, tps, "tps", "getTPS", "test");
        Sponge.getCommandManager().register(plugin, tabbar, "tabbar", "tabbar", "tabbar");
    }
}

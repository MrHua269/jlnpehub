package com.ccccc.plug.tps;

import org.spongepowered.api.Sponge;
import org.spongepowered.api.command.CommandException;
import org.spongepowered.api.command.CommandResult;
import org.spongepowered.api.command.CommandSource;
import org.spongepowered.api.command.args.CommandContext;
import org.spongepowered.api.command.spec.CommandExecutor;
import org.spongepowered.api.command.spec.CommandSpec;
import org.spongepowered.api.plugin.PluginContainer;
import org.spongepowered.api.text.Text;
import org.spongepowered.api.event.game.state.GameStartedServerEvent;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.plugin.Plugin;
public abstract class gettps implements PluginContainer {
   public static CommandSpec tps = CommandSpec.builder()
            .description(Text.of("Get the server tps"))
            .permission("com.ccccc.plug.tps")
            .executor(new TPSGet())
            .build();


}




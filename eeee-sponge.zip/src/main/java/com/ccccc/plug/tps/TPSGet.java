package com.ccccc.plug.tps;

import org.spongepowered.api.Sponge;
import org.spongepowered.api.command.CommandException;
import org.spongepowered.api.command.CommandResult;
import org.spongepowered.api.command.CommandSource;
import org.spongepowered.api.command.args.CommandContext;
import org.spongepowered.api.command.spec.CommandExecutor;
import org.spongepowered.api.text.Text;
import org.spongepowered.api.text.format.TextColors;
import java.lang.management.ManagementFactory;
import com.sun.management.OperatingSystemMXBean;

public class TPSGet implements CommandExecutor {
    @Override
    public CommandResult execute(CommandSource src, CommandContext args) throws CommandException {
        src.sendMessage(Text.of("-------------------------------"));
        src.sendMessage(TPS());
        src.sendMessage(Text.of("MaxPlayers : " + MaxPlayers()));
        src.sendMessage(Text.of("Runned time : " + Sponge.getServer().getRunningTimeTicks()/1200 + "minutes"));
        src.sendMessage(Text.of("CPU : " + cpuLoad()+"%"));
        src.sendMessage(Text.of("System memory uesd : " + memoryLoad() + "%"));
        src.sendMessage(Text.of("-------------------------------"));
        return CommandResult.success();
    }

    public static Text TPS(){
        if(Sponge.getServer().getTicksPerSecond() > 20){
            return Text.of(TextColors.GREEN,"TPS : *20");
        } else if(Sponge.getServer().getTicksPerSecond() >17 ){
            return Text.of(TextColors.GREEN,"TPS : ",Sponge.getServer().getTicksPerSecond());
        }else if (Sponge.getServer().getTicksPerSecond() > 13 && Sponge.getServer().getTicksPerSecond() < 17){
          return Text.of(TextColors.YELLOW,"TPS : " ,Sponge.getServer().getTicksPerSecond());
      }else if (Sponge.getServer().getTicksPerSecond() > 0 && Sponge.getServer().getTicksPerSecond() <13){
          return Text.of(TextColors.RED,"TPS : " ,Sponge.getServer().getTicksPerSecond());
      }else {
          return Text.of("TPS : " + "Unknow");
      }
    }
    public static int MaxPlayers(){
        return Sponge.getServer().getMaxPlayers();
    }
    private static OperatingSystemMXBean osmxb = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
    public static int cpuLoad() {
        double cpuLoad = osmxb.getSystemCpuLoad();
        int percentCpuLoad = (int) (cpuLoad * 100);
        return percentCpuLoad;

    }
    public static int memoryLoad() {
        double totalvirtualMemory = osmxb.getTotalPhysicalMemorySize();
        double freePhysicalMemorySize = osmxb.getFreePhysicalMemorySize();

        double value = freePhysicalMemorySize/totalvirtualMemory;
        int percentMemoryLoad = (int) ((1-value)*100);
        return percentMemoryLoad;

    }
}

package com.ccccc.plug.tabbar;

import org.spongepowered.api.command.CommandResult;
import org.spongepowered.api.command.CommandSource;
import org.spongepowered.api.command.args.CommandContext;
import org.spongepowered.api.command.args.GenericArguments;
import org.spongepowered.api.command.spec.CommandSpec;
import org.spongepowered.api.entity.living.player.Player;
import org.spongepowered.api.text.Text;
import org.spongepowered.api.text.format.TextColors;

public class register {
    public static CommandSpec tabbar = CommandSpec.builder()
            .description(Text.of("This is a command of tabbar"))
            .permission("com.ccccc.tabbar")
            .arguments(
                    GenericArguments.onlyOne(GenericArguments.player(Text.of("player"))),
                    GenericArguments.remainingJoinedStrings(Text.of("message")),
                    GenericArguments.string(Text.of("Color")))
            .executor((CommandSource src, CommandContext args) -> {

                Player player = args.<Player>getOne("player").get();
                String message = args.<String>getOne("message").get();
                player.getTabList().setHeaderAndFooter(Text.of(message),Text.of(message));

                return CommandResult.success();
            })
            .build();
}

package com.ccccc.tablists;

import org.spongepowered.api.entity.living.player.tab.TabList;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.entity.living.humanoid.player.RespawnPlayerEvent;
import org.spongepowered.api.text.Text;
import org.spongepowered.api.text.format.TextColors;

import java.nio.charset.StandardCharsets;

public class main {
    public static String getName = "Unknow";
    @Listener
    public void tabmain(RespawnPlayerEvent event){
        getName = event.getTargetEntity().getName();
        TabList getTablist = event.getTargetEntity().getTabList();
        getTablist.setHeaderAndFooter(masges(),masges());
    }

    public Text masges(){
        if(getName == "wangxyper"){
            return Text.of(TextColors.BLUE,new String("emm").getBytes(StandardCharsets.ISO_8859_1));
        }
        else if (getName == "look" ){
          return Text.of( TextColors.GREEN,"eeeee");
        }else {
         return Text.of(TextColors.GREEN,new String("Shit ").getBytes(StandardCharsets.ISO_8859_1));
        }
    }

}
